const form = document.getElementById('weatherForm');
const myCity = document.getElementById('city');
const image = document.getElementById('weatherImage');
const weather = document.getElementById('weatherMain');
const temp = document.querySelector('.temp');
const dates = document.querySelector('.todayDates');
const times = document.getElementById('todayTime');
const cityNameInput = document.getElementById('weatherInput'); // Ambil input berdasarkan ID HTML
let date = new Date();

// Function work when user input the city name
form.addEventListener('submit', function (e) {
    // preventDefault() to stop page reload
    e.preventDefault();

    // Updating the city name
    let city = cityNameInput.value; // Gunakan cityNameInput untuk mendapatkan nilai kota
    const myWeatherContainer = document.querySelector('.weatherContainer');
    const apiID = `931f131dde3f4ae2fcbc3289fc646471`; 
    // API URL
    let url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiID}`;

    // fetching data from the weather api
    fetch(url)
        .then((response) => {
            return response.json();
        })
        .then((data) => {
            if (data.cod === 200) { // Periksa apakah permintaan API berhasil (kode 200 OK)
                const tempValue = Math.round(data['main']['temp']);
                const weatherMain = data['weather'][0]['main'];
                weather.innerHTML = weatherMain;

                // Updating the DOM
                myCity.innerHTML = data.name; // Gunakan data.name dari respons API
                temp.innerHTML = `${tempValue}<span><sup>o</sup>C</span>`;
                weather.innerHTML = `${weatherMain}`;

                // Updating the Images according to the weather
                if (weatherMain === 'Clear') {
                    image.src = `./Images/sunny.png`;
                    myWeatherContainer.style.backgroundColor = '#ec6e4c';
                } else if (weatherMain === 'Clouds') {
                    image.src = `./Images/clouds.png`;
                    myWeatherContainer.style.backgroundColor = '#86d3d3';
                } else if (weatherMain === 'Rain') {
                    image.src = `./Images/Rain.png`;
                    myWeatherContainer.style.backgroundColor = '#494bcf';
                } else if (weatherMain === 'Drizzle') {
                    image.src = `./Images/Drizzle.png`;
                    myWeatherContainer.style.backgroundColor = '#8ecfcf';
                } else if (weatherMain === 'Haze' || weatherMain === 'Mist' || weatherMain === 'Fog') { // Tambahkan Mist dan Fog jika perlu
                    image.src = `./Images/Drizzle.png`; // Anda mungkin ingin gambar yang berbeda untuk Haze/Mist/Fog
                    myWeatherContainer.style.backgroundColor = '#d8ced2';
                } else if (weatherMain === 'Thunderstorm') {
                    image.src = `./Images/Thunderstorm.png`; // Tambahkan gambar untuk badai
                    myWeatherContainer.style.backgroundColor = '#363636';
                } else if (weatherMain === 'Snow') {
                    image.src = `./Images/Snow.png`; // Tambahkan gambar untuk salju
                    myWeatherContainer.style.backgroundColor = '#f0f8ff';
                } else {
                    image.src = ``; // Gambar default atau kosong jika cuaca tidak dikenali
                    myWeatherContainer.style.backgroundColor = '#f0f0f0'; // Warna background default
                }

                // Updating dates
                const currentMonth = date.getMonth();
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept.", "Oct.", "Nov", "Dec"];
                dates.innerHTML = `${date.getDate()}, ${monthNames[currentMonth]}`;

                // Updating times
                function updateTime() {
                    const now = new Date();
                    let hours = now.getHours();
                    let minutes = now.getMinutes();
                    let seconds = now.getSeconds();
                    const ampm = hours >= 12 ? 'PM' : 'AM';

                    hours = hours % 12;
                    hours = hours ? hours : 12; // the hour '0' should be '12'
                    minutes = minutes < 10 ? '0' + minutes : minutes;
                    seconds = seconds < 10 ? '0' + seconds : seconds;

                    times.innerHTML = `${hours}h:${minutes}m:${seconds}s ${ampm}`;
                }
                setInterval(updateTime, 1000);
            } else {
                // Tangani kasus jika kota tidak ditemukan (data.cod bukan 200)
                myCity.innerHTML = "Kota tidak ditemukan";
                temp.innerHTML = "";
                weather.innerHTML = "";
                image.src = "";
                myWeatherContainer.style.backgroundColor = '#f0f0f0';
            }
        })
        .catch((error) => {
            console.error("Terjadi kesalahan saat mengambil data:", error);
            myCity.innerHTML = "Terjadi kesalahan";
            temp.innerHTML = "";
            weather.innerHTML = "";
            image.src = "";
            myWeatherContainer.style.backgroundColor = '#f0f0f0';
        });
});